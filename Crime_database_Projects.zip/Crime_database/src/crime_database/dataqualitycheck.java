/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crime_database;

//import com.sun.istack.internal.logging.Logger;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;

/**
 *
 * @author qmahmoo9
 */
public class dataqualitycheck  {

    private static Object st;
    public static void main(String[] args) {
        
    PrintWriter outputStream = null;
    
        try {
            outputStream =  new PrintWriter(new FileOutputStream("nocrimeid.txt"));
        } catch (FileNotFoundException ex) {
            java.util.logging.Logger.getLogger(dataqualitycheck.class.getName()).log(Level.SEVERE, null, ex);
        }
    

    
        try {

//            Database_connector connect = new Database_connector();
//            Statement stmt;
//            ResultSet rs;
//            String query = " Select * From Crimdata WHERE`Crime ID`=''";
//            Statement Database_connector = null;
//            stmt = connect()
//             rs = st.executeQuery(query);
             Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://lamp.scim.brad.ac.uk:3306/qmahmoo9", "qmahmoo9", "Ip0dinit");
        Statement stmt = con.createStatement();
        //ResultSet rs = stmt.executeQuery( "Select * From crimedata WHERE `LSOA name` = 'Leeds 001A'");
          ResultSet rs = stmt.executeQuery( "Select * From crimedata");
        while (rs.next()) {
           String crimeID = rs.getString("Crime ID");
           System.out.println(crimeID);
           outputStream.println(crimeID);
           String Month = rs.getString("Month");
            System.out.println(Month);
           outputStream.println(Month);
             String Reportby = rs.getString("Reported by");
            System.out.println(Reportby);
             outputStream.println(Reportby);
           String FallsWithin = rs.getString("Falls within");
            System.out.println(FallsWithin);
           outputStream.println(FallsWithin);
           String Longitude = rs.getString("Longitude");
            System.out.println(Longitude);
           outputStream.println(Longitude);
           String Latitude = rs.getString("Latitude");
            System.out.println(Latitude);
           outputStream.println(Latitude);
           String Location = rs.getString("Location");
            System.out.println(Location);
           outputStream.println(Location);
           String Lsoacode = rs.getString("LSOA code");
            System.out.println(Lsoacode);
           outputStream.println(Lsoacode);
           String Lsoaname = rs.getString("LSOA name");
            System.out.println(Lsoaname);
           outputStream.println(Lsoaname);
           String crimetype = rs.getString("Crime type");
            System.out.println(crimetype);
           outputStream.println(crimetype);
           String lastcategory = rs.getString("Last outcome category");
            System.out.println(lastcategory);
           outputStream.println(lastcategory);
           String context = rs.getString("Context");
            System.out.println(context);
           outputStream.println(context);
//                String longitude = rs.getString("Longitude");
//                outputStream.println(longitude);
//                String latitude = rs.getString("latitude");
//                String crimeID = rs.getString("crime ID");
//                String Month = rs.getString("month");
//                String Reportedby = rs.getString("Reported by");
//                String FallsWithin = rs.getString("Falls Within");
//                String Location = rs.getString("Location");
//                String LSOACode = rs.getString("LSOA Code");
//                String LSOAName = rs.getString("LSOA Name");
//                String CrimeType = rs.getString("Crime Type");
//                String Lastoutcomecategory = rs.getString("Last outcome category");
//                String Context = rs.getString("Context");
            } 
        }
        catch (SQLException ex) {
            System.out.println("SQL Exception"+ex.getMessage());
        }catch(ClassNotFoundException cnfe){
            System.out.println("CNFE");
        }
    
}
}





