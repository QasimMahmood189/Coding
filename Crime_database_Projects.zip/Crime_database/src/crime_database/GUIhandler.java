/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crime_database;

import static com.sun.xml.internal.fastinfoset.alphabet.BuiltInRestrictedAlphabets.table;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;

public class GUIhandler {

    JButton x = new JButton("print");
    JLabel y = new JLabel("Display Combo Items");
    JScrollPane tableScrollPane = new JScrollPane();
  
    
    private JFrame fr;
    private JPanel P;
    public GUIhandler() {

        gui();

    }

    public void gui() {
        fr = new JFrame("Crime Data Base");

        fr.setVisible(true);
        fr.setSize(1650, 500);
        fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        P = new JPanel();
        P.setBackground(Color.WHITE);
        

        JLabel label = new JLabel("Longitude");
        label.setPreferredSize(new Dimension(60, 25));
        P.add(label);

        JTextField textField = new JTextField();
        textField.setPreferredSize(new Dimension(200, 20));
        P.add(textField);

        JButton button = new JButton("search");
        button.setPreferredSize(new Dimension(100, 25));
        P.add(button);
        button.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                String searchString = textField.getText();
                Database_connector dbc = new Database_connector();
                dbc.getLongitudeTable(searchString);
                
            }
            
        });
        
        

        JLabel labeltwo = new JLabel("Latitude");
        labeltwo.setPreferredSize(new Dimension(50, 25));
        P.add(labeltwo);

        JTextField textFieldtwo = new JTextField();
        textFieldtwo.setPreferredSize(new Dimension(200, 20));
        P.add(textFieldtwo);

        JButton buttontwo = new JButton("search");
        buttontwo.setPreferredSize(new Dimension(100, 25));
        P.add(buttontwo);
        buttontwo.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                String s = textFieldtwo.getText();
                Database_connector dbc = new Database_connector();
                dbc.getLatitudeTable(s);
            }
            
        });

        JLabel labelThird = new JLabel("LSOA / code ");
        labelThird.setPreferredSize(new Dimension(75, 25));
        P.add(labelThird);

        JTextField textFieldThird = new JTextField();
        textFieldThird.setPreferredSize(new Dimension(200, 20));
        P.add(textFieldThird);

        JButton buttonThird = new JButton("search");
        buttonThird.setPreferredSize(new Dimension(100, 25));
        P.add(buttonThird);
        buttonThird.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
             String s = textFieldThird.getText();
                Database_connector dbc = new Database_connector();
                dbc.getLSOATable(s);   
            }
            
        });
        
       JLabel label4 = new JLabel("Crime Type");
        label4.setPreferredSize(new Dimension(75, 25));
        P.add(label4);

//          JTextField textField4 = new JTextField();
//        textField4.setPreferredSize(new Dimension(200, 20));
//        P.add(textField4);
        
               
        JTextField textField4 = new JTextField();
        textField4.setPreferredSize(new Dimension(200, 20));
        P.add(textField4);


        JButton button4 = new JButton("ENQUIRE");
        button4.setPreferredSize(new Dimension(100, 25));
        P.add(button4);
       button4.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                 String searchString = textField4.getText();
                Database_connector dbc = new Database_connector();
               dbc.getCrimeTypeTable(searchString);
            }
            
        });
        
  
        
        Database_connector trythis = new Database_connector();
       // tableScrollPane.add(t);
      //  t.setVisible(true);
       // tableScrollPane.setVisible(true);

       
        fr.add(P, BorderLayout.NORTH);
        P.revalidate();
        P.setVisible(true);
        fr.add(tableScrollPane, BorderLayout.CENTER);
        
        fr.revalidate();
        x.addActionListener(new ActionListener() {
            public void actionPerform(ActionEvent e) {
                //String s = c.getSelectedItem().toString();
         //       y.setText(s);
            }
  
   
        
            @Override
            public void actionPerformed(ActionEvent ae) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
    }

    public static void main(String[] args) {
        new GUIhandler();
        String a;
        a = JOptionPane.showInputDialog("Please enter your name");
        JOptionPane.showMessageDialog(null, "Logged on as " + a);
        

        String s;
        try {
            Database_connector connect = new Database_connector();
            connect.getData();


           
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR");
        } finally {
            try {
                System.out.println("Results Fully Functioning");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "ERROR CLOSE");
            }
        }
        }
    public static DefaultTableModel buildTableModel(ResultSet rs)
    throws SQLException {

ResultSetMetaData metaData = rs.getMetaData();

// names of columns
Vector<String> columnNames = new Vector<String>();
int columnCount = metaData.getColumnCount();
for (int column = 1; column <= columnCount; column++) {
    columnNames.add(metaData.getColumnName(column));
}

// data of the table
Vector<Vector<Object>> data = new Vector<Vector<Object>>();
while (rs.next()) {
    Vector<Object> vector = new Vector<Object>();
    for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
        vector.add(rs.getObject(columnIndex));
    }
    data.add(vector);
}

return new DefaultTableModel(data, columnNames);

}
}



/**
 *
 * @author qmahmoo9
 */
